using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Dashboard.Views.Home
{
    public class CronogramaModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
